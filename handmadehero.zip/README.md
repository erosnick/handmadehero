# handmadehero
My follow up to the handmadehero project. 

https://handmadehero.org/

/*

When I was little,
Games were made from scratch
By people who loved them.

There were no licensed engines.
Each pixely little hero was coded by hand.

My thirty years of game programming
Were inspired by this way of life
And I believe it is worth passing on.

So I am starting a project
To help preserve it.

Join me as wee code a complete game.

By hand, from scratch, together.

*/